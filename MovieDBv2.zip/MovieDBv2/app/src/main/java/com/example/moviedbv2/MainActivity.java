package com.example.moviedbv2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationItemView;
import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
   MaterialButton mb1;
   MaterialButton mb2;

    BottomNavigationItemView bn1;
    BottomNavigationItemView bn2;
    BottomNavigationItemView bn3;
    BottomNavigationItemView bn4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //rate
        mb1=(MaterialButton) findViewById(R.id.rate);
        mb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Main2Activity.class));
            }
        });

        //add to watchlist
        mb2=(MaterialButton) findViewById(R.id.add_to_watchlist);
        mb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Movie added to watchlist",Toast.LENGTH_LONG).show();
            }
        });

        //search
        bn1=(BottomNavigationItemView) findViewById(R.id.nav2);
        bn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Main3Activity.class));
            }
        });

        //ratings
        bn2=(BottomNavigationItemView) findViewById(R.id.nav3);
        bn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Main4Activity.class));
            }
        });

        //wishlist
        bn3=(BottomNavigationItemView) findViewById(R.id.nav4);
        bn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Main5Activity.class));
            }
        });

        //home
        bn4=(BottomNavigationItemView) findViewById(R.id.nav1);
        bn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });
    }


}
